import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, NgForm, FormGroupDirective } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { AppServiceService } from 'src/app/app-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ErrorStateMatcher } from '@angular/material/core';
import * as XLSX from 'xlsx';
import { AppSettings } from 'src/app/app.settings';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { SimpleDynamicTabelComponent } from 'src/app/shared/simple-dynamic-tabel/simple-dynamic-tabel.component';
import { AppEnum } from 'src/app/theme/enum/app.enum';
import { SelectionModel } from '@angular/cdk/collections';

type AOA = any[][];

@Component({
  selector: 'app-upload-employee',
  templateUrl: './upload-employee.component.html',
  styleUrls: ['./upload-employee.component.scss']
})
export class UploadEmployeeComponent implements OnInit {
  uploadData: FormGroup;
  public companyList;
  isDataPosting: boolean;
  isFileUpload: boolean;
  PostingData = [];
  public IsProceed: boolean;
  public companyId;
  public ClientId;
  public ReqTemplateModel: getTemplateModel;
  public loginInfo = JSON.parse(this._appService.decryptUsingAES256(localStorage.getItem('loginInfo')));
  public companyData = JSON.parse(this._appService.decryptUsingAES256(localStorage.getItem('companyData')));

  public configId = this.companyData.configId;
  public itemDocument: FileUploader = new FileUploader({ isHTML5: true, disableMultipart: false });
  FileReader: FileReader = new FileReader();
  errorMatcher = new CustomErrorStateMatcher();

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  public moduleList;
  public templateList;
  templateColumn: string[] = [];
  templateData = new MatTableDataSource();

  @ViewChild('sheetForm') sheetForm: NgForm;
  exceldata: AOA = [];
  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  public templateColumnData = [];
  public importMode;
  public tempexcelData;
  public tempFinalData;
  public isyearMonth;
  public isAmountType;
  public isDocumentStatus;
  public YearsList;
  public moduleId;
  public templateId;
  public UpdateDataTbl;
  selection = new SelectionModel(true, []);
  public advanceFilterobserbable;
  public advanceFilterValues = null;
  public amountStatusMaster;
  public NoDataFound = false;
  constructor(public _appSetting: AppSettings, public _appService: AppServiceService, public _appEnum: AppEnum,
    private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, public dialog: MatDialog) {
    this.companyId = this.companyData.companyId;
    this.ClientId = this.companyData.ClientId;
    this.YearsList = _appService.previousyearslist(new Date().getFullYear(), 5);
    this._appService.getData("Organization/getOrganizationlist?orgId=" + parseInt(this.companyData.companyId) + "&parentId=" + this.companyData.orgId).subscribe(compDetl => {
      if (compDetl.Status == true) {
        this.companyList = compDetl.Data;
      }
    });
    this.route.queryParamMap.subscribe(params => {
      if (params.keys.length > 0) {
      }
    });
  }
  ngOnInit(): void {
    console.log(this.companyData, 'this.companyData');

    this.isDataPosting = false;
    this.isFileUpload = false;
    this.IsProceed = false;
    if (this.configId == 2) {
      this.moduleId = this._appEnum.EntityModuleMaster.Payroll;
      this.templateId = this._appEnum.EntitytemplateMaster.PayrollAttendance;
      this._appService.getData('resource/getimportexporttemplate?moduleId=' + this.moduleId).subscribe(templates => {
        this.templateList = templates.Data;
        this.isyearMonth = true;
      });
      this.FileReader.onload = (ev: any) => {
        console.log(ev.target.result);
      };
      this.itemDocument.onAfterAddingFile = (fileItem: any) => {
        this.FileReader.readAsText(fileItem._file);
      };
    }
    this._appService.getData("admin/payroll/getpayrollmasterlist?tblName=Payroll_Investment_Amount_Status").subscribe(data => {
      this.amountStatusMaster = data.Data
    });
    this.uploadData = this.formBuilder.group({
      module: [this.moduleId == undefined || this.moduleId == null ? '' : this.moduleId.toString(), Validators.required],
      template: [this.templateId == undefined || this.templateId == null ? '' : this.templateId.toString(), Validators.required],
      AttYear: [this.companyData.Year == undefined || this.companyData.Year == null ? '' : this.companyData.Year.toString()],
      AttMonth: [this.companyData.month == undefined || this.companyData.month == null ? '' : this.companyData.month.toString()],
      PayCycle: [this.companyData.payCycle == undefined || this.companyData.payCycle == null ? '' : this.companyData.payCycle.toString()],
      AmountType: [''],
      documentStatus: [''],
      documentFile: [''],
      mode: [null, [Validators.required]]
    });

    this._appService.getData('resource/getmodules').subscribe(modules => {
      this.moduleList = modules.Data;
    });
    // this._appService.getData('resource/getpayrollcycles?ComapanyId='+this.companyId+'&ClientId='+this.ClientId).subscribe(data =>{
    //   this.payCycleList = data.Data;
    // });
    this._appService.advanceFilterReset.next(true);
    this.advanceFilterobserbable = this._appService.advanceFilterValues.subscribe(data => {
      this.advanceFilterValues = data;
      this.changeMode();
      this._appSetting.IsopenAdvanceSearch = false;
    })
  }
  checkDownload() {
    if (this.importMode == 'update' && this.UpdateDataTbl) {
      return true;
    } else if (this.importMode == 'insert' && this.templateColumnData.length > 0) {
      return true;
    } else {
      return false;
    }
  }
  GetUpdateTemplateData() {
    if (this.importMode == 'update') {
      this._appSetting.settings.loadingSpinner = true;
      this.getRequestModel();
      this.clearFileField();
      this.UpdateDataTbl = undefined;
      this._appService.postData('document/getupdatetemplatedata', this.ReqTemplateModel).subscribe(data => {
        this._appSetting.settings.loadingSpinner = false;
        var UpdateData = data.Status ? data.Data : [];
        if (UpdateData.length != 0) {
          this.NoDataFound = false;
          var columns = Object.keys(UpdateData[0]);
          this.UpdateDataTbl = {
            headerColumn: columns,
            selectAll: false,
            ActionColumn: false,
            searchBar: true,
            paging: true,
            ActionLink: { view: false, edit: false, delete: false },
            dataSource: UpdateData,
          };
        } else {
          this.NoDataFound = true;
        }
      });
    }
  }
  ngOnDestroy(): void {
    this.advanceFilterobserbable.unsubscribe();
  }
  chkIntermidiate() {
    var selected = this.templateColumnData.filter(el => el.forUpdate == true).length;
    if (selected > 0) {
      return (this.templateColumnData.length != selected) ? true : false;
    } else {
      return null;
    }
  }
  isAllSelected() {
    const numSelected = this.templateColumnData.length;
    return numSelected == this.templateColumnData.filter(el => el.forUpdate == true).length;
  }
  masterToggle() {
    this.isAllSelected() ? this.templateColumnData.map(el => el.forUpdate = false) : this.selectRows();
  }
  selectRows() {
    for (let index = 0; index < this.templateColumnData.length; index++) {
      this.templateColumnData[index].forUpdate = true;
    }
  }
  changeModules(module) {
    if (module) {
      this._appSetting.settings.loadingSpinner = true;
      this.uploadData.controls['template'].setValue('');
      this.uploadData.controls['mode'].setValue('');
      this._appService.getData('resource/getimportexporttemplate?moduleId=' + module).subscribe(templates => {
        this.templateList = templates.Data;
        this._appSetting.settings.loadingSpinner = false;
      });
    }
    this.changeTemplate();
  }
  changeTemplate() {
    this.UpdateDataTbl = undefined;
    //this.uploadData.controls['mode'].setValue('');
    var templateValue = this.uploadData.controls['template'].value;
    if (templateValue == this._appEnum.EntitytemplateMaster.ChapterIVADetails ||
      templateValue == this._appEnum.EntitytemplateMaster.HRADetails ||
      templateValue == this._appEnum.EntitytemplateMaster.IncomeFromOtherSource ||
      templateValue == this._appEnum.EntitytemplateMaster.Perquisites) {
      this.isAmountType = templateValue == this._appEnum.EntitytemplateMaster.ChapterIVADetails ? true : false,
        this.isDocumentStatus = templateValue != this._appEnum.EntitytemplateMaster.ChapterIVADetails ? true : false
    } else if (templateValue == this._appEnum.EntitytemplateMaster.PayrollAttendance) {
      this.isyearMonth = true;
    } else {
      this.isAmountType = false;
      this.isDocumentStatus = false;
      this.isyearMonth = false;
      this.uploadData.controls['AttYear'].setValue('');
      this.uploadData.controls['AttMonth'].setValue('');
      this.uploadData.controls['PayCycle'].setValue('');
    }
  }
  goToPayroll() {
    var JsonData = {
      connfigPageName: '', orgId: this.loginInfo[0].OrganizationId,
      companyId: this.companyData?.companyId,
      configId: 2, ClientId: this.companyData?.ClientId,
      tabIndexId: 0, steaperId: 0, secondaryIndex: 0, pageTitle: '', orgTitle: '',
      Year: this.uploadData.controls['AttYear'].value,
      month: this.uploadData.controls['AttMonth'].value,
      payCycle: this.uploadData.controls['PayCycle'].value
    }
    localStorage.setItem('companyData', this._appService.encryptUsingAES256(JsonData));
    this.router.navigate(['/panel/payroll/add-edit-process-payroll']);
  }
  getRequestModel() {
    if (this.uploadData.invalid) {
      this.ReqTemplateModel = new getTemplateModel();
    }
    else {
      this.ReqTemplateModel = new getTemplateModel();
      this.ReqTemplateModel.loginId = this.loginInfo[0].EmployeeId;
      this.ReqTemplateModel.module = this.uploadData.controls['module'].value;
      this.ReqTemplateModel.template = this.uploadData.controls['template'].value;
      this.ReqTemplateModel.mode = this.importMode;
      this.ReqTemplateModel.attMonth = this.uploadData.controls['AttMonth'].value == '' ? 0 : this.uploadData.controls['AttMonth'].value;
      this.ReqTemplateModel.attYear = this.uploadData.controls['AttYear'].value == '' ? 0 : this.uploadData.controls['AttYear'].value;
      this.ReqTemplateModel.FinancialYearId = 0;
      this.ReqTemplateModel.AdvanceFilter = this._appService.getFilterObject(this.advanceFilterValues);
    }
  }
  changeMode() {
    this.clearFileField();
    this.changeTemplate();
    this.templateColumn = undefined;
    this.templateData = undefined;
    this.UpdateDataTbl = undefined;
    this.templateColumnData = [];
    var module = this.uploadData.controls['module'].value;
    var template = this.uploadData.controls['template'].value;
    this.importMode = this.uploadData.controls['mode'].value;
    if (module != '' && template != '' && this.importMode != null && this.importMode != "") {
      this.getRequestModel();

      this._appSetting.settings.loadingSpinner = true;
      this._appService.getData('document/getcolumnbindings?module=' + module + '&template=' + template + '&mode=' + this.importMode).subscribe(data => {
        this._appSetting.settings.loadingSpinner = false;
        if (data.Status) {
          this.templateColumnData = data.Data;
        } else {
          this.templateData = undefined;
          this.templateColumn = [];
          this.importMode = undefined;
          this.clearFileField();
        }
        if (this.importMode == 'update') {
          this.GetUpdateTemplateData();
          this.NoDataFound = true;
        }
      });
    } else {
      this.templateData = undefined;
      this.templateColumn = [];
      this.importMode = undefined;
      this.clearFileField();
    }
  }
  onFileChange(evt: any) {
    this.templateData = undefined;
    this.UpdateDataTbl = undefined;
    this.templateData = new MatTableDataSource();
    this.templateColumn = [];
    this.tempFinalData = [];
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length == 0) {
      this.clearFileField();
      return;
    }
    if (target.files.length > 1) {
      Swal.fire('', 'Cannot use multiple files', 'error');
      this.clearFileField();
      return;
    }

    for (let i = 0; i < this.itemDocument.queue.length; i++) {
      let fileItem = this.itemDocument.queue[i]._file;
      if (fileItem.type != 'application/vnd.ms-excel' && fileItem.type != 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
        Swal.fire('', "Please select only excel file.", 'error');
        this.clearFileField();
        return;
      }
      if (fileItem.size > 5242880) {
        Swal.fire('', "File should be less than 5 MB of size.", 'error');
        this.clearFileField();
        return;
      }
    }
    this._appSetting.settings.loadingSpinner = true;
    this.NoDataFound = false;
    const reader: FileReader = new FileReader();
    reader.readAsBinaryString(target.files[0]);
    reader.onload = (e: any) => {
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];
      // this.exceldata = XLSX.utils.sheet_to_json(ws, { header: 1 }); 
      this.exceldata = XLSX.utils.sheet_to_json(ws, { range: "A1:IV1", header: 1 });
      this.validateRow(this.exceldata);
      this._appSetting.settings.loadingSpinner = false;
    };
  }
  validateRow(excelData) {
    if (excelData.length == 0) {
      Swal.fire('', 'Header column should be start from A1 cell.');
      return;
    }
    var ths = this;
    excelData = excelData[0];
    this.templateColumnData = this.templateColumnData.map((item, i) => {
      var found = excelData.includes(item.MappedColumnName);
      item.MappingColumnName = found ? item.MappedColumnName : null;
      if (item.isRequired) {
        ths.sheetForm.controls['sheetColumn' + i].markAsTouched();
      }
      return item;
    });
    this._appSetting.settings.loadingSpinner = false;
  }
  getRowColor(error: any): string {
    if (error == null) { }
    else { return 'rowColor'; }
  }
  exportTemplate() {
    if (this.uploadData.invalid) {
      return;
    }
    var AttYear = this.uploadData.controls['AttYear'].value;
    var AttMonth = this.uploadData.controls['AttMonth'].value;
    if (this.isyearMonth) {
      if (AttYear == '' || AttMonth == '') {
        Swal.fire('', 'Please select Month and year.', 'error');
        return;
      }
    }
    //var externalUrl = this.isyearMonth ? '&attMonth='+AttMonth+'&attYear='+AttYear: "";
    // this.ReqTemplateModel.attMonth = this.isyearMonth ? AttMonth : 0;
    // this.ReqTemplateModel.attYear = this.isyearMonth ? AttYear : 0;
    this.getRequestModel();
    var baseurl = new URL(this._appService.apiUrl).toString();
    var api_Url = baseurl.replace('/api/', '');
    this._appSetting.settings.loadingSpinner = true;
    this._appService.postData('document/gettemplate', this.ReqTemplateModel).subscribe(data => {
      if (data.Status) {
        var filePath = api_Url + data.Data;
        fetch(filePath).then(response => {
          if (response.status == 404) {
            Swal.fire('', 'File not found!', 'error');
            return
          }
          response.blob().then(blob => {
            let url = window.URL.createObjectURL(blob);
            let a = document.createElement('a');
            a.href = url;
            a.download = data.Data;
            a.click();
          });
        });
      } else {
        Swal.fire('', data.Message, 'error');
      }
      this._appSetting.settings.loadingSpinner = false;
    })
  }
  uploadDocuments(formValue) {
    var ths = this;
    if (this.uploadData.invalid || this.sheetForm.invalid) {
      return;
    }
    this.isFileUpload = true;
    this.companyId = formValue.companyId;
    this.ClientId = formValue.clientId == '' || formValue.clientId == null || formValue.clientId == undefined ? 0 : formValue.clientId;
    const formData1 = new FormData();
    if (this.itemDocument.queue.length <= 0) {
      Swal.fire("Please select the file.");
      this.isFileUpload = false;
      return;
    }
    else {
      for (let i = 0; i < this.itemDocument.queue.length; i++) {
        let fileItem = this.itemDocument.queue[i]._file;
        formData1.append("fileUpload", fileItem);
      }
      var templateModule = this.uploadData.controls['module'].value;
      var template = this.uploadData.controls['template'].value;

      // formData1.append("CompanyId", formValue.companyId);
      // formData1.append("ClientId", formValue.clientId == null || formValue.clientId == "" ? 0 : formValue.clientId);
      formData1.append("Module", templateModule);
      formData1.append("Template", template);
      formData1.append("Mode", this.importMode);
      formData1.append("AttYear", this.isyearMonth ? formValue.AttYear : "");
      formData1.append("AttMonth", this.isyearMonth ? formValue.AttMonth : "");
      formData1.append("PayCycle", this.isyearMonth ? formValue.PayCycle : "");
      formData1.append("AmountType", this.isAmountType ? formValue.AmountType : "");

      formData1.append("AddedBy", this.loginInfo[0].EmployeeId);
    }

    this._appService.upload('UploadExcelData', formData1).subscribe(data => {
      if (data.Status == true && data.StatusCode == 201) {
        Swal.fire(data.Message).then((ok) => {
          this.templateColumn = Object.keys(data.Status ? data.Data.Validation[0] : []);
          this.openDialog(Object.keys(data.Status ? data.Data.Validation[0] : []), data.Status ? data.Data.Validation : []);
          this.tempFinalData = data.Status ? data.Data.ExcelData : [];
          sessionStorage.setItem('exData', JSON.stringify(data.Status ? data.Data.ExcelData : []));
          this.isFileUpload = false;
          console.log(data.Data.Validation, (data.Data.Validation.filter(item => item.isValidated == 0)).length)
          if ((data.Data.Validation.filter(item => item.isValidated == 0)).length > 0) {
            ths.clearFileField();
            this.IsProceed = true;
          } else {
            this.IsProceed = false;
          }
        });
      }
      else if (data.Status == false && (data.StatusCode == 203 || data.StatusCode == 204)) {
        Swal.fire(data.Message).then((ok) => {
          this.uploadData.reset();
          ths.clearFileField();
          this.isFileUpload = false;
        });
      }
    }, err => {
      Swal.fire(err.Message).then((ok) => {
        ths.clearFileField();
        this.isFileUpload = false;
      });
    });
  }
  clearFileField() {
    if (<HTMLInputElement>document.getElementById('fileControl')) {
      (<HTMLInputElement>document.getElementById('fileControl')).value = "";
      this.itemDocument.clearQueue();
    }
  }
  openDialog(columns, tableData) {
    var dialogConfig = new MatDialogConfig();
    dialogConfig.data = {
      headerColumn: columns,
      selectAll: false,
      ActionColumn: false,
      ActionLink: { view: false, edit: true, delete: true },
      filterEntity: new tableModal(),
      dataSource: tableData,
    };
    dialogConfig.panelClass = "dynamicTablePopup";
    const dialogRef = this.dialog.open(SimpleDynamicTabelComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      // console.log(tableData,'tableDatatableData');
      // var isSucess=tableData.filter(item => item.isValidated == 0);
      // console.log(isSucess,'isSucessisSucess');
      // if (this.configId == '2' && isSucess?.length==0) {
      //   this.goToPayroll();
      // }      
    });
  }
  mapDataForPost(columData, tempFinalData) {
    console.log(columData, 'columDatacolumData')
    var postingData = {};
    var dataObject = undefined;

    dataObject = tempFinalData.map((item, i) => {
      var t = this.tempFinalData[i];
      columData.map((el, j) => {
        item[el.MappedColumnName] = t[el.MappingColumnName];
        if (this.importMode == 'update') {
          var tempobj = {}
          tempobj['CompanyId'] = t['CompanyId'];
          tempobj['ClientId'] = t['ClientId'];
          tempobj['value'] = t[el.MappingColumnName];
          // tempobj['SqlTableName'] = el.SqlTableName;
          tempobj['MappingColumnName'] = el.MappedColumnName;
          tempobj['updatedBy'] = this.loginInfo[0].EmployeeId;
          tempobj['forUpdate'] = el.forUpdate;
          item[el.MappedColumnName] = tempobj;
          if (!el.forUpdate) {
            // delete item[el.MappedColumnName];
            delete item['AddedBy'];
            delete item['RowError'];
            delete item['CompanyId'];
            delete item['ClientId'];
          }
        }
      });
      return item;
    });
    var templateModule = this.uploadData.controls['module'].value;
    var template = this.uploadData.controls['template'].value;
    postingData['module'] = templateModule;
    postingData['template'] = template;
    postingData['mode'] = this.importMode;
    postingData['dataObject'] = dataObject;
    return postingData;
  }
  validateMappedColumn() {
    var ths = this;
    this.templateColumnData.forEach((el, i) => {
      if (el.SqlColumnName != el.MappingColumnName) {
        ths.sheetForm.controls['sheetColumn' + i].markAsTouched();
      }
    });
  }
  SubmitData() {
    var ths = this;
    var templateData: any = this.templateData;
    var checkErrorStatus = templateData.filteredData.filter(v => v.isValidated == 0);
    if (checkErrorStatus.length > 0) {
      Swal.fire('', 'Check the upload excel sheet there is some error please reupload the excel sheet', 'error');
      return false;
    }
    const uplodedExcelData = JSON.parse(sessionStorage.getItem('exData'));
    var postJson = this.mapDataForPost(this.templateColumnData, uplodedExcelData);
    this.isDataPosting = true;
    var dispTxt = "Are you sure? Post data.";
    Swal.fire({
      text: dispTxt,
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'YES',
      cancelButtonText: 'NO'
    }).then((result) => {
      if (result.value) {
        // var url = this.importMode == 'insert' ? 'insertexceldata' : 'updateexceldata';
        console.log(postJson, 'postJsonpostJsonpostJson');
        this._appService.postData('insertupdateexceldata', postJson).subscribe(data => {
          if (data.Status == true) {
            this.templateData = undefined;
            this.templateData = new MatTableDataSource(data.Data);
            this.templateData.sort = this.sort;
            Swal.fire(data.Message).then((ok) => {
              var templateColumn = Object.keys(data.Status ? data.Data[0] : []);
              ths.openDialog(templateColumn, data.Status ? data.Data : []);
              ths.clearFileField();
              this.isDataPosting = false;
              this.IsProceed = true;
              sessionStorage.removeItem('exData');
              if (this.configId == '2') {
                this.goToPayroll();
              }
              this.onClear();
            });
          }
          else {
            Swal.fire(data.Message).then((ok) => {
              ths.clearFileField();
              this.isDataPosting = false;
              sessionStorage.removeItem('exData');
            });
          }
        }, err => {
          Swal.fire(err.message).then((ok) => {
            ths.clearFileField();
            this.isDataPosting = false;
            sessionStorage.removeItem('exData');
          });
        });
      } else {
        this.onClear();
        this.isDataPosting = false;
        sessionStorage.removeItem('exData');
      }
    });
  }
  getErrorsInData(origArray = []) {
    var count = 0;
    var reCount = 0;
    var errorList = { "count": 0, "reCount": 0 };
    origArray.forEach(element => {
      for (let key in element) {
        if (element[key].error != null) {
          var error: string = element[key].error;
          if (error.includes('required')) {
            reCount = reCount + 1;
          } else {
            count = count + 1;
          }
        }
      }
    });
    errorList.count = count;
    errorList.reCount = reCount;
    return errorList;
  }
  onClear() {
    this.templateData = undefined;
    this.templateColumn = undefined;
    this.clearFileField();
    this.uploadData.reset();
    this.importMode = undefined;
    this.IsProceed = false;
  }

}
export class CustomErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl, form: NgForm | FormGroupDirective | null) {
    return control && control.invalid && control.touched;
  }
}

export class tableModal {
  EmployeeCode: string;
  EmployeeName: string;
  UploadInfo: string;
  isValidated: string;
}

export class getTemplateModel {
  loginId: number;
  module: number;
  template: number;
  mode: string;
  attMonth: number;
  attYear: number;
  FinancialYearId: number;
  AmountType: number;
  AdvanceFilter: any;
}