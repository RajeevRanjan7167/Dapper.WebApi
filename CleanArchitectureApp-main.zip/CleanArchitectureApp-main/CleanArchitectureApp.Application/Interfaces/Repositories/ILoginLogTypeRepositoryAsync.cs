using CleanArchitectureApp.Domain;

namespace CleanArchitectureApp.Application.Interfaces.Repositories
{
    public interface ILoginLogTypeRepositoryAsync : IGenericRepositoryAsync<LoginLogType>
    {

    }
}