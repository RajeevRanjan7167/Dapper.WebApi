namespace CleanArchitectureApp.Domain
{
    public partial class LoginLogType
    {
        public virtual System.Guid LoginLogTypeId { get; set; }
        public virtual string LoginLogTypeName { get; set; }
    }
}