export interface User {
  id: string| undefined;
  username: string| undefined;
  firstname: string| undefined;
  lastname: string| undefined;
  status: string | undefined;
  createddate: any;
  token: string | undefined;
  refreshToken: string | undefined;
}

