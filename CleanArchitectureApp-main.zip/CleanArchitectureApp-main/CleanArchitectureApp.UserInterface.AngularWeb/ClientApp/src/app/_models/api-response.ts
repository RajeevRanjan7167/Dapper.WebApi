
export interface ApiResponse {
  succeeded: boolean;
  message: string;
  errors: string;
  data: any;
}

