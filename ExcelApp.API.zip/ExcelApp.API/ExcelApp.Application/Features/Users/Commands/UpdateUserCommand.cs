﻿using MediatR;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ExcelApp.Application.Features.Users.Commands
{
    public class UpdateUserCommand: IRequest<int>
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserEmail { get; set; }
        public string UpdatedBy { get; set; }

        public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, int>
        {
            private readonly IExcelDBContext _context;

            public UpdateUserCommandHandler(IExcelDBContext context)
            {
                this._context = context;
            }

            public async Task<int> Handle(UpdateUserCommand command, CancellationToken cancellationToken)
            {
                var user = _context.Users.Where(ur => ur.UserId == command.UserId).FirstOrDefault();
                if (user == null)
                    return default;

                user.FirstName = command.FirstName;
                user.LastName = command.LastName;
                user.UserEmail = command.UserEmail;
                user.UpdatedBy = command.UpdatedBy;
                user.UpdatedBy = "Admin";
                user.UpdatedDate = DateTime.UtcNow;

                await _context.SaveChangesAsync();
                return user.UserId;
            }
        }
    }
}
