﻿using ExcelApp.Domain.Entities;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace ExcelApp.Application.Features.Users.Commands
{
    public class CreateUserCommand: IRequest<int>
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserEmail { get; set; }
        public string CreatedBy { get; set; }

        public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, int>
        {
            private readonly IExcelDBContext _context;
            private readonly IPasswordService _passwordService;

            public CreateUserCommandHandler(IExcelDBContext context, IPasswordService passwordService)
            {
                this._context = context;
                this._passwordService = passwordService;
            }

            public async Task<int> Handle(CreateUserCommand command, CancellationToken cancellationToken)
            {
                string passwordHash, passwordSalt;

                var user = new User();
                user.UserName = command.UserName;
                user.FirstName = command.FirstName;
                user.LastName = command.LastName;
                user.UserEmail = command.UserEmail;
                _passwordService.CreatePasswordHash(command.Password, out passwordHash, out passwordSalt);
                user.PasswordHash = passwordHash;
                user.PasswordSalt = passwordSalt;
                user.CreatedBy = "Admin";
                user.CreatedDate = DateTime.UtcNow;

                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                return user.UserId;
            }
        }
    }
}
