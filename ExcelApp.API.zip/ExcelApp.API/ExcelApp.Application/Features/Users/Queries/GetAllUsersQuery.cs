﻿using ExcelApp.Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace ExcelApp.Application.Features.Users.Queries
{
    public class GetAllUsersQuery : IRequest<IEnumerable<User>>
    {
        public class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, IEnumerable<User>>
        {
            private readonly IExcelDBContext _context;
            public GetAllUsersQueryHandler(IExcelDBContext context)
            {
                this._context = context;
            }

            public async Task<IEnumerable<User>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
            {
                var userList = await _context.Users.ToListAsync();
                if (userList == null)
                    return null;

                return userList.AsReadOnly();
            }            
        }
    }
}
