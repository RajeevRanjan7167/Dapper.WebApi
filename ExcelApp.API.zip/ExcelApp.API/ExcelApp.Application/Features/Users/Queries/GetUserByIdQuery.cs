﻿using ExcelApp.Domain.Entities;
using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ExcelApp.Application.Features.Users.Queries
{
    public class GetUserByIdQuery : IRequest<User>
    {
        public int userId { get; set; }

        public class GetUserByIdQueryHandler : IRequestHandler<GetUserByIdQuery, User>
        {
            private readonly IExcelDBContext _context;
            public GetUserByIdQueryHandler(IExcelDBContext context)
            {
                this._context = context;
            }

            public async Task<User> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
            {
                var user = await _context.Users.Where(ur => ur.UserId == request.userId).FirstOrDefaultAsync();
                if (user == null)
                    return null;

                return user;
            }
        }
    }
}
