﻿using ExcelApp.Application.Features.Users.Commands;
using ExcelApp.Application.Features.Users.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ExcelApp.API.Controllers
{
    public class UserController : BaseApiController
    {
        private IMediator _mediator;

        public UserController(IMediator mediator)
        {
            this._mediator = mediator;
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateUserCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _mediator.Send(new GetAllUsersQuery()));
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> GetById(int userId)
        {
            return Ok(await _mediator.Send(new GetUserByIdQuery { userId = userId }));
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Update(int id, UpdateUserCommand command)
        {
            if (id != command.UserId)
                return BadRequest();

            return Ok(await _mediator.Send(command));
        }
    }
}
