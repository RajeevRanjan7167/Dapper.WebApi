﻿using ExcelApp.Application;
using ExcelApp.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelApp.Persistence
{
    public class ExcelDBContext : DbContext,IExcelDBContext
    {
        public ExcelDBContext(DbContextOptions<ExcelDBContext> options): base(options) {} 

        public DbSet<User> Users { get; set; }
        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }
    }
}
