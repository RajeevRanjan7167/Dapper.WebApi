import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatTableFilter } from 'mat-table-filter';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';
import { AppServiceService } from 'src/app/app-service.service';
import Swal from 'sweetalert2';
import { AppSettings } from 'src/app/app.settings';

@Component({
  selector: 'app-advance-table-component',
  templateUrl: './advance-table-component.component.html',
  styleUrls: ['./advance-table-component.component.scss']
})

export class AdvanceTableComponentComponent implements OnInit {
  @Input() tableData;

  public headerColumn: string[] = [];
  public dataSource = new MatTableDataSource();
  public IsPaging=true;
  public totalrows=0;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  selection = new SelectionModel(true, []);

  public filterEntity;
  public filterType = MatTableFilter.ANYWHERE;
  isSearchRow = false;

  public displayedSearchColumns;
  public searchFieldForTable = [];

  @Output() getRowDetails = new EventEmitter()
  @Output() getSelectedRows = new EventEmitter()
  constructor(public _appService: AppServiceService, public _appSettings: AppSettings,) {
  }

  ngOnInit(): void {
    this._appSettings.settings.loadingSpinner = true;
    this.headerColumn = this.tableData.headerColumn; //.map(item => {
    //   return item.replace(" ","-");
    // });
    this.IsPaging=this.tableData?.paging==true ||this.tableData?.paging==undefined?true:false;
    this.totalrows=this.tableData?.dataSource.length;
    this.filterEntity = {};

    if (this.tableData.selectAll) {
      this.headerColumn.splice(0, 0, "SelectAll");
    }
    if (this.tableData.ActionColumn) {
      this.headerColumn.splice(this.headerColumn.length, 0, "Action");
    }
    this.displayedSearchColumns = this.headerColumn.map(cl => {
      if (cl == "SelectAll" || cl == "Action") {
        this.searchFieldForTable.push({ columnName: "search-" + cl, mappingColumnName: cl, searchIcon: false, searchable: false })
      } else {
        this.searchFieldForTable.push({ columnName: "search-" + cl, mappingColumnName: cl, searchIcon: true, searchable: false });
      }
      return "search-" + cl;
    });

    this.dataSource = new MatTableDataSource(this.tableData.dataSource);
    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
    this._appSettings.settings.loadingSpinner = false;
  }

  IsDate(dateString) {
    if (dateString && !Number.isInteger(dateString)) {
      // console.log(dateString, Number.isInteger(dateString))
      return this.isValidDate(dateString)
    }
  }

  isValidDate = date => {
    date = new Date(date);
    return !!(Object.prototype.toString.call(date) === "[object Date]" && +date)
  }


  dutchRangeLabel = (page: number, pageSize: number, length: number) => {
    if (length == 0 || pageSize == 0) { return { startIndex: 0, endIndex: 0 }; }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return { startIndex: startIndex, endIndex: endIndex }
  }

  ngAfterViewInit(): void {
    if (this.IsPaging) {
      this.paginator.page.subscribe(x => {
        this.selection.clear();
      });
    } else {
      this.selection.clear();
    }
  }
  isAllSelected() {
    // const numSelected = this.dataSource.filteredData.length; 
    const numSelected = this.selection.selected.length;
    //alert(this.IsPaging);
    if (this.IsPaging) {
      var pageRange = this.dutchRangeLabel(this.dataSource.paginator.pageIndex, this.dataSource.paginator.pageSize, this.dataSource.filteredData.length);
      return numSelected === (pageRange['endIndex'] - pageRange['startIndex']);
    } else {
      const numRows = this.dataSource.data.length;
      return numSelected === numRows;
    }

  }

  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.selectRows();
  }

  selectRows() {
    if (this.IsPaging) {
      var pageRange = this.dutchRangeLabel(this.dataSource.paginator.pageIndex, this.dataSource.paginator.pageSize, this.dataSource.filteredData.length);
      for (let index = pageRange['startIndex']; index < pageRange['endIndex']; index++) {
        this.selection.select(this.dataSource.filteredData[index]);
      }
    } else {
      this.dataSource.data.forEach(row => {
      this.selection.select(row);
      });
    }

  }

  selectRow(e) {
    if (this.tableData['tableFor'] == 'openingBalanceComponent')
      this._appService.advanceTableSelectedRows.next(this.dataSource.filteredData);
    e.stopPropagation();
  }

  searchColumn(event, columnName) {
    this.selection.clear();
    this.searchFieldForTable.map(obj => {
      if (obj.mappingColumnName == columnName) {
        obj.searchable = !obj.searchable;
        if (!obj.searchable) { this.filterEntity[columnName] = ""; }
      }
      return obj;
    });
    var temp = [];
    this.searchFieldForTable.forEach(obj => {
      temp.push(obj.searchable);
    });
    this.isSearchRow = temp.includes(true);

    if (!this.isSearchRow) {
      Object.keys(this.filterEntity).forEach(key => {
        this.filterEntity[key] = "";
      });
      this.dataSource.filter = "";
    }
    event.stopPropagation();
    event.preventDefault();
  }

  clickRow(item, action) {
    if (item.length == 0) {
      Swal.fire('', 'Please select at least one row from table', 'error');
      return;
    }
    this.getRowDetails.emit({ item: item, action: action });
  }
  GetRows(ev) {
    this.getSelectedRows.emit(this.selection.selected);
  }
  
}